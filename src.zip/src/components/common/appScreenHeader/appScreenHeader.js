import { useState } from "react";

import AppHeader from "../appHeader/appHeader";
import SideMenu from "../sideMenu/sideMenu";

export default function AppScreenHeader({
  title,
  navigation,
  showMenu = true,
  onNotificationPress,
  onProfilePress,
}) {
  const [menuVisible, setMenuVisible] = useState(false);

  function handleMenuPress() {
    if (!showMenu) {
      navigation.goBack();
      return;
    }

    setMenuVisible(true);
  }

  return (
    <>
      <AppHeader
        title={title}
        onMenuPress={handleMenuPress}
        onNotificationPress={
          onNotificationPress || (() => {})
        }
        onProfilePress={
          onProfilePress || (() => {})
        }
      />

      {showMenu && (
        <SideMenu
          visible={menuVisible}
          onClose={() => setMenuVisible(false)}
          navigation={navigation}
        />
      )}
    </>
  );
}