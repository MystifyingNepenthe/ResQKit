export default {
  navigation: {
    home: "Acasă",
    vehicle: "Vehicul",
    guides: "Ghiduri",
    settings: "Setări",
  },

  common: {
    search: "Caută...",
    save: "Salvează",
    cancel: "Anulează",
    back: "Înapoi",
    continue: "Continuă",
    connected: "Conectat",
    disconnected: "Deconectat",
  },

  home: {
    title: "Acasă",
    welcome: "Bine ai venit!",
    searchPlaceholder: "Caută ghiduri...",
    myResQKit: "ResQKit-ul meu",
    deviceStatus: "Starea dispozitivului",
    status: "Stare",
    battery: "Baterie",
    lastSync: "Ultima sincronizare",
    justNow: "Chiar acum",
    resyncNow: "Sincronizează acum",
    connectNow: "Conectează acum",
  },

  vehicle: {
    title: "Vehicul",
    vehicleInformation: "Informații vehicul",
    model: "Model",
    licensePlate: "Număr de înmatriculare",
    vin: "Serie șasiu (VIN)",
    locateTitle: "Localizează ResQKit",
    locateDescription:
      "Redă un sunet pe dispozitiv pentru a-l găsi mai ușor.",
    findResQKit: "Găsește ResQKit",
  },

  guides: {
    title: "Ghiduri",
    searchPlaceholder: "Caută ghiduri...",
    woundGuides: "Ghiduri pentru răni",
    appGuides: "Ghiduri aplicație",

    categories: {
      cuts: "Tăieturi",
      burns: "Arsuri",
      bleeding: "Sângerări",
      fractures: "Fracturi",
      cpr: "Resuscitare (RCP)",
      choking: "Sufocare",
      poisoning: "Otrăvire",
      allergicReaction: "Reacție alergică",
      carAccident: "Accident rutier",
    },

    appCategories: {
        gettingStarted: "Introducere",
        connectResQKit: "Conectarea ResQKit",
        home: "Pagina Acasă",
        vehicle: "Vehicul",
        ai: "Asistent AI",
        settings: "Setări",
    },

    emergency: {
      low: "URGENȚĂ REDUSĂ",
      medium: "URGENȚĂ MEDIE",
      high: "URGENȚĂ RIDICATĂ",
    },
  },

  ai: {
    title: "Asistent ResQKit AI",
    subtitle: "Cum te pot ajuta?",
    messagePlaceholder: "Scrie un mesaj...",
    analyzeWound: "Analizează o rană",
    firstAid: "Prim ajutor",
    checkResQKit: "Verifică ResQKit",
    askQuestion: "Pune o întrebare",
    quickSuggestions: "Sugestii rapide",
    attachPhoto: "Atașează fotografie",
    camera: "Cameră",
    gallery: "Galerie",
  },

  settings: {
    title: "Setări",
    account: "Cont",
    vehicle: "Vehicul",
    device: "Dispozitiv",
    notifications: "Notificări",
    language: "Limbă",
    theme: "Temă",
    help: "Ajutor",
    about: "Despre aplicație",
    logout: "Deconectare",
    romanian: "Română",
    english: "Engleză",
    lightTheme: "Deschisă",
    darkTheme: "Întunecată",
  },

  account: {
    title: "Cont",
    personalInformation: "Date personale",
    firstName: "Prenume",
    lastName: "Nume",
    email: "Adresă de e-mail",
    password: "Parolă",
  },

  auth: {
    welcome: "Bine ai venit!",
    signInSubtitle: "Autentifică-te pentru a continua",
    email: "Adresă de e-mail",
    password: "Parolă",
    signIn: "Autentificare",
    register: "Creează cont",
    forgotPassword: "Ai uitat parola?",
    noAccount: "Nu ai un cont?",
    alreadyHaveAccount: "Ai deja un cont?",
  },
};