export const FONTS = {
  regular: "System",
  medium: "System",
  bold: "System",

  h1: 32,
  h2: 28,
  h3: 24,
  h4: 20,

  body: 16,
  bodySmall: 14,

  caption: 12,
};